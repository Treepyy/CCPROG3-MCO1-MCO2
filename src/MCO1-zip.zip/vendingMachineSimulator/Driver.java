package vendingMachineSimulator;

/**
 * Driver class for executing the program.
 */
public class Driver {

    /*
        TODO: demo video
     */
    public static void main(String[] args) {

        MainMenu menu = new MainMenu();
        menu.displayMenu();
    }

}