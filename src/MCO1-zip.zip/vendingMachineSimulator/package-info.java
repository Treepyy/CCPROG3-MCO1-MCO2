/**
 * Vending Machine simulator for the first phase of CCPROG3 major course output.
 *
 * @author  Vance Gyan M. Robles
 * @version 1.0
 * @since   2023-06-01
 */

package vendingMachineSimulator;